﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace sla
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] valores = new double[7, 5];
            double[] totalpordia = new double[7];
            string aux;



            string[] diasdasemana = { "domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado" };

            for (int i = 0; i < 7; i++) {
                for (int j = 0; j < 5; j++) {

                    Interaction.InputBox($"Digite os valores do produto{j + 1} dia semana {diasdasemana[i]}");
                    if (!Double.TryParse(aux out valores[i, j]) || valores[i, j] = 0) {











                    }


                }



            }
        }
    }
}
