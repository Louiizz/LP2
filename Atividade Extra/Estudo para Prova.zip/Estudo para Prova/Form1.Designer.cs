﻿namespace Estudo_para_Prova
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexecutar = new System.Windows.Forms.Button();
            this.lstbox = new System.Windows.Forms.ListBox();
            this.btnexecutar2 = new System.Windows.Forms.Button();
            this.lstbox2 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnexecutar
            // 
            this.btnexecutar.Location = new System.Drawing.Point(21, 25);
            this.btnexecutar.Name = "btnexecutar";
            this.btnexecutar.Size = new System.Drawing.Size(221, 41);
            this.btnexecutar.TabIndex = 0;
            this.btnexecutar.Text = "Executar1";
            this.btnexecutar.UseVisualStyleBackColor = true;
            this.btnexecutar.Click += new System.EventHandler(this.btnexecutar_Click);
            // 
            // lstbox
            // 
            this.lstbox.FormattingEnabled = true;
            this.lstbox.ItemHeight = 16;
            this.lstbox.Location = new System.Drawing.Point(21, 91);
            this.lstbox.Name = "lstbox";
            this.lstbox.Size = new System.Drawing.Size(221, 324);
            this.lstbox.TabIndex = 1;
            // 
            // btnexecutar2
            // 
            this.btnexecutar2.Location = new System.Drawing.Point(292, 25);
            this.btnexecutar2.Name = "btnexecutar2";
            this.btnexecutar2.Size = new System.Drawing.Size(221, 41);
            this.btnexecutar2.TabIndex = 2;
            this.btnexecutar2.Text = "Executar2";
            this.btnexecutar2.UseVisualStyleBackColor = true;
            this.btnexecutar2.Click += new System.EventHandler(this.btnexecutar2_Click);
            // 
            // lstbox2
            // 
            this.lstbox2.FormattingEnabled = true;
            this.lstbox2.ItemHeight = 16;
            this.lstbox2.Location = new System.Drawing.Point(292, 91);
            this.lstbox2.Name = "lstbox2";
            this.lstbox2.Size = new System.Drawing.Size(221, 324);
            this.lstbox2.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1375, 762);
            this.Controls.Add(this.lstbox2);
            this.Controls.Add(this.btnexecutar2);
            this.Controls.Add(this.lstbox);
            this.Controls.Add(this.btnexecutar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnexecutar;
        private System.Windows.Forms.ListBox lstbox;
        private System.Windows.Forms.Button btnexecutar2;
        private System.Windows.Forms.ListBox lstbox2;
    }
}

