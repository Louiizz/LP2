﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Estudo_para_Prova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[4, 3];
            double[] medias = new double[4];
         

            lstbox.Items.Clear();

            for (int i = 0; i < 4; i++)
            {
                double somanotas = 0;

                for (int j = 0; j < 3; j++)
                {
                    string valordigitado = Interaction.InputBox($"Digite a nota {j + 1} do Aluno {i + 1}", "Entradas de Notas");

                    if (!double.TryParse(valordigitado, out matriz[i, j]))
                    {
                        matriz[i, j] = 0;
                    }

                    somanotas += matriz[i, j];
                }
                medias[i] = somanotas / 3;
            }
            lstbox.Items.Clear();

            for (int i = 0; i < 4; i++)
            {
                lstbox.Items.Add($"Aluno {i + 1} : {medias[i]:N2}");
            }
        }

        private void btnexecutar2_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[3, 4];
            double[] totalporregiao = new double[3];
            string[] regioes = { "Sul", "Sudeste", "Centro-Oeste" };
            double faturamentototal = 0; 

            lstbox2.Items.Clear();

            for (int i = 0; i < 3; i++)
            {
                double somaregiao = 0;

                for (int j = 0; j < 4; j++)
                {
                    string valordigitado = Interaction.InputBox($"Digite o faturamento do {j + 1} Trimestre da região {regioes[i]}");

                    if (!double.TryParse(valordigitado, out matriz[i, j]))
                    {
                        matriz[i, j] = 0; 
                    }
                    somaregiao += matriz[i, j];

                    faturamentototal += matriz[i, j]; 

                }
                totalporregiao[i] = somaregiao;
            }   
            lstbox2.Items.Clear();

            for (int i = 0; i < 3; i++)
            {
                lstbox2.Items.Add($"Região {regioes[i]} : {totalporregiao[i]:N2}");
            }
            lstbox2.Items.Add("--------------------");

            lstbox2.Items.Add($"Faturamento Total : {faturamentototal:N2}");
        }

    }

}   

