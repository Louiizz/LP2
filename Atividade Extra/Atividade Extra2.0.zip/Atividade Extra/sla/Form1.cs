﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace sla
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] compras = new double[7, 5]; // Matriz de 7 linhas (semana) e 5 colunas (produtos).
            double[] totalpordia = new double[7]; // Vetor para armazenar o total de compras de cada um dos 7 dias.
            double totalgeral = 0; // Variável acumuladora para o total de toda a semana.
            string[] aux = { "Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado" }; // Vetor auxiliar apenas para exibir o nome correto dos dias na saída

            for (int i = 0; i < 7; i++)  // O primeiro laço (for) percorre as 7 linhas (os dias)
            {
                double somalinha = 0; // Armazena a soma das compras do dia atual

                for (int j = 0; j < 5; j++) // O segundo laço (for) percorre as 5 colunas (os produtos) para o dia atual
                {
                    string input = Interaction.InputBox($"Digite o valor do produto {j + 1} para o dia {aux[i]}:", "Entrada de Dados");     // Abre a InputBox solicitando o valor do produto

                    if (!double.TryParse(input, out compras[i, j]))  // Converte o texto digitado para double. Se for vazio ou inválido, assume 0.
                    {
                        compras[i, j] = 0;
                    }

                    somalinha += compras[i, j]; // Acumula o valor do produto na soma do dia atual
                }

                totalpordia[i] = somalinha; // Guarda o total calculado da linha (dia) no vetor correspondente

                totalgeral += somalinha; // Acumula o total desse dia no grande total da semana
            }

            lstbox.Items.Clear(); // Limpa o ListBox antes de mostrar novos resultados (evita duplicar se clicar de novo)

            for (int i = 0; i < 7; i++)
            {
                lstbox.Items.Add($"{aux[i]} : {totalpordia[i]:N2}"); // formata o valor como moeda/decimal (:N2 adiciona duas casas decimais)
            }

            lstbox.Items.Add("-------------------------"); // Adiciona a linha separadora conforme o exemplo de saída da imagem

            lstbox.Items.Add($"totalgeral : {totalgeral:N2}"); // Adiciona o valor total geral formatado no final do ListBox
        }
    }
}
        
    

