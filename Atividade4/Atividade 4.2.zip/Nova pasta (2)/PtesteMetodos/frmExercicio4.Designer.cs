﻿namespace PtesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtrich = new System.Windows.Forms.RichTextBox();
            this.btncontn = new System.Windows.Forms.Button();
            this.btnposi1 = new System.Windows.Forms.Button();
            this.btncontl = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtrich
            // 
            this.txtrich.Location = new System.Drawing.Point(50, 46);
            this.txtrich.Name = "txtrich";
            this.txtrich.Size = new System.Drawing.Size(659, 375);
            this.txtrich.TabIndex = 0;
            this.txtrich.Text = "";
            // 
            // btncontn
            // 
            this.btncontn.Location = new System.Drawing.Point(50, 496);
            this.btncontn.Name = "btncontn";
            this.btncontn.Size = new System.Drawing.Size(114, 93);
            this.btncontn.TabIndex = 1;
            this.btncontn.Text = "Conta Números";
            this.btncontn.UseVisualStyleBackColor = true;
            this.btncontn.Click += new System.EventHandler(this.btncontn_Click);
            // 
            // btnposi1
            // 
            this.btnposi1.Location = new System.Drawing.Point(225, 496);
            this.btnposi1.Name = "btnposi1";
            this.btnposi1.Size = new System.Drawing.Size(114, 93);
            this.btnposi1.TabIndex = 2;
            this.btnposi1.Text = "Posição 1 Caracter Branco";
            this.btnposi1.UseVisualStyleBackColor = true;
            this.btnposi1.Click += new System.EventHandler(this.btnposi1_Click);
            // 
            // btncontl
            // 
            this.btncontl.Location = new System.Drawing.Point(405, 496);
            this.btncontl.Name = "btncontl";
            this.btncontl.Size = new System.Drawing.Size(114, 93);
            this.btncontl.TabIndex = 3;
            this.btncontl.Text = "Conta Letras";
            this.btncontl.UseVisualStyleBackColor = true;
            this.btncontl.Click += new System.EventHandler(this.btncontl_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1226, 697);
            this.Controls.Add(this.btncontl);
            this.Controls.Add(this.btnposi1);
            this.Controls.Add(this.btncontn);
            this.Controls.Add(this.txtrich);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtrich;
        private System.Windows.Forms.Button btncontn;
        private System.Windows.Forms.Button btnposi1;
        private System.Windows.Forms.Button btncontl;
    }
}