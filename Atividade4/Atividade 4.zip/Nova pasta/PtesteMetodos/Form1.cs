﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            Close();   
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Menu Copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Menu Colar");
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
           {
                Application.OpenForms["frmExercicio2"].BringToFront();
            
            }
           else
            {
                frmExercicio2 FrmExercício = new frmExercicio2();
                FrmExercício.MdiParent = this;
                FrmExercício.WindowState = FormWindowState.Maximized;
                FrmExercício.Show();



            }



        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
       
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                Application.OpenForms["frmExercicio3"].BringToFront();

            }
            else
            {
                frmExercicio3 FrmExercício = new frmExercicio3();
                FrmExercício.MdiParent = this;
                FrmExercício.WindowState = FormWindowState.Maximized;
                FrmExercício.Show();



            }


        }
    }
}
