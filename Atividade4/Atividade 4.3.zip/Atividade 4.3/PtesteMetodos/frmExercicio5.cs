﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnsorteio_Click(object sender, EventArgs e)
        {

            if (!int.TryParse(txtde.Text, out int de) || !int.TryParse(txtate.Text, out int ate))
            {
                return;
            }
            Random Obj = new Random();
            int sorteio = Obj.Next(de, ate);
            MessageBox.Show(sorteio.ToString());
        }
    }

}
