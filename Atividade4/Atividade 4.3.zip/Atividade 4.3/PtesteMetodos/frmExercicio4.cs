﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btncontn_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contaNum = 0;

            while (posicao < txtrich.Text.Length)
            {
                if (char.IsNumber(txtrich.Text[posicao]))
                {
                    contaNum++; //contaNum +=1
                }

                posicao++;
            }
            MessageBox.Show($"a frase tem {contaNum} números");


        }

        private void btnposi1_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < txtrich.Text.Length; i++)
            {
                if (char.IsWhiteSpace(txtrich.Text[i]))
                {
                    posicao = i + 1;
                    break;

                }


            }
            if (posicao == 0)
                MessageBox.Show("não há caracteres em branco na frase");
            else
                MessageBox.Show($"o 1 caracter em branco está na posição {posicao}");



        }

        private void btncontl_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;

            foreach (char c in txtrich.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"a frase tem {contaLetra} letras");

        }
    }
}