﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void frmExercicio6_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int metade = txtpalavra2.Text.Length / 2;

            txtpalavra2.Text =
                txtpalavra2.Text.Substring(0, metade) +
                txtpalavra1.Text +
                txtpalavra2.Text.Substring(metade, txtpalavra2.Text.Length - metade);

          
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
