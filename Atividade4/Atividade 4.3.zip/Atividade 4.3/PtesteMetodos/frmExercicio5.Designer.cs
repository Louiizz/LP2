﻿namespace PtesteMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblde = new System.Windows.Forms.Label();
            this.lblate = new System.Windows.Forms.Label();
            this.txtde = new System.Windows.Forms.TextBox();
            this.txtate = new System.Windows.Forms.TextBox();
            this.btnsorteio = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblde
            // 
            this.lblde.AutoSize = true;
            this.lblde.Location = new System.Drawing.Point(80, 74);
            this.lblde.Name = "lblde";
            this.lblde.Size = new System.Drawing.Size(28, 16);
            this.lblde.TabIndex = 0;
            this.lblde.Text = "Dê:";
            this.lblde.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblate
            // 
            this.lblate.AutoSize = true;
            this.lblate.Location = new System.Drawing.Point(414, 74);
            this.lblate.Name = "lblate";
            this.lblate.Size = new System.Drawing.Size(30, 16);
            this.lblate.TabIndex = 1;
            this.lblate.Text = "Até:";
            // 
            // txtde
            // 
            this.txtde.Location = new System.Drawing.Point(115, 74);
            this.txtde.Name = "txtde";
            this.txtde.Size = new System.Drawing.Size(240, 22);
            this.txtde.TabIndex = 2;
            // 
            // txtate
            // 
            this.txtate.Location = new System.Drawing.Point(450, 74);
            this.txtate.Name = "txtate";
            this.txtate.Size = new System.Drawing.Size(240, 22);
            this.txtate.TabIndex = 3;
            // 
            // btnsorteio
            // 
            this.btnsorteio.Location = new System.Drawing.Point(83, 121);
            this.btnsorteio.Name = "btnsorteio";
            this.btnsorteio.Size = new System.Drawing.Size(99, 63);
            this.btnsorteio.TabIndex = 4;
            this.btnsorteio.Text = "Sorteio";
            this.btnsorteio.UseVisualStyleBackColor = true;
            this.btnsorteio.Click += new System.EventHandler(this.btnsorteio_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1038, 570);
            this.Controls.Add(this.btnsorteio);
            this.Controls.Add(this.txtate);
            this.Controls.Add(this.txtde);
            this.Controls.Add(this.lblate);
            this.Controls.Add(this.lblde);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblde;
        private System.Windows.Forms.Label lblate;
        private System.Windows.Forms.TextBox txtde;
        private System.Windows.Forms.TextBox txtate;
        private System.Windows.Forms.Button btnsorteio;
    }
}