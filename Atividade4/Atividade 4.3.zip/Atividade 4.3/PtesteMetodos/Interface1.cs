﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PtesteMetodos
{
    internal interface Interface1
    {
    }
}
