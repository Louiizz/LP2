﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double num1, num2, resul;


        public Form1()
        {
            InitializeComponent();



        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void txtnum2_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtnum2.Text, out num1))
            {
                MessageBox.Show("Inválido");
                e.Cancel = true;
            }
        }

        private void txtresul_Validated(object sender, EventArgs e)
        {
            
        }

        private void btnsomar_Click(object sender, EventArgs e)
        {
           
            resul = num1 + num2;
            txtresul.Text = resul.ToString();

        }

        private void btnsomar_Click(object sender, EventArgs e, double resul)
        {
        }

        private void btnsomar_Click(object sender, EventArgs e, string resul)
        {
                    
        }

        private void txtresul_TextChanged(object sender, EventArgs e)
        { 
           
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void txtnum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum1.Text, out num1))
            {
                MessageBox.Show("Inválido");
                txtnum1.Focus();
            }
        }
    }
}
