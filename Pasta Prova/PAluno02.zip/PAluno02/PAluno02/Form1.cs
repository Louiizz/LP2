﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[2, 3];
            double[] medias = new double[3];
            string[] aux = { "Professor 1", "Professor 2", "Professor 3" };
            string[] aux2 = { "Aluno 1", "Aluno 2"};
            double mediageral = 0;
            double[] notas = new double[3];

            lstbox.Items.Clear();

            for (int i = 0; i < 2; i++)
            {
                double somanotas = 0;

                for (int j = 0; j < 3; j++)
                {
                    string valordigitado = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de Notas");

                    if (!double.TryParse(valordigitado, out matriz[i, j]))
                    {
                        matriz[i, j] = 0;
                    }
                    

                        somanotas += matriz[i, j];

                    
                }


                medias[i] = somanotas / 3;

                mediageral += medias[i] / 2;

                notas[i] = notas[i];
                
            }
            lstbox.Items.Clear();

            for (int i = 0; i < 2; i++)
            {
                lstbox.Items.Add($"Nota {aux[i]}: {medias[i]}");            
            }
            lstbox.Items.Add("--------------------------");

            lstbox.Items.Add($"Media Geral Alunos: {mediageral:N2}");
        }
    }
}

                
            
     