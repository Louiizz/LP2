﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Matriz
{
    public partial class frmexercicio5 : Form
    {
        public frmexercicio5()
        {
            InitializeComponent();
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {
            int quantidadeAlunos = 3;
            int quantidadeQuestoes = 10;

            char[,] matrizRespostas = new char[quantidadeAlunos, quantidadeQuestoes];
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };

            rch.Clear();

            for (int i = 0; i < quantidadeAlunos; i++)
            {
                for (int j = 0; j < quantidadeQuestoes; j++)
                {
                    string entrada = Interaction.InputBox(
                        $"Aluno {i + 1}\nResposta da Questão {j + 1}:",
                        "Correção de Prova"
                    ).ToUpper().Trim();

                    if (entrada.Length == 1 && "ABCDE".Contains(entrada))
                    {
                        matrizRespostas[i, j] = char.Parse(entrada);
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida! Digite apenas A, B, C, D ou E.");
                        j--;
                    }
                }
            }
            for (int i = 0; i < quantidadeAlunos; i++)
            {
                for (int j = 0; j < quantidadeQuestoes; j++)
                {
                    char respAluno = matrizRespostas[i, j];
                    char respCorreta = gabarito[j];

                    string status = (respAluno == respCorreta) ? "acertou" : "errou";

                    string linha = $"O aluno:{i + 1} {status} questão:{j + 1} era {respCorreta} escolheu {respAluno}";

                    rch.AppendText(linha + "\n");
                }
            }
        }
    }
}
