﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P_Matriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                int[] vetor = new int[20];
                string aux = "";
                for (int i = 0; i < 20; i++)
                {

                    aux = Interaction.InputBox($"Digite o número {i++}", "Entrada de dados");

                    if (!int.TryParse(aux, out vetor[i]))
                    {
                        MessageBox.Show("Valor inválido");
                        i--;
                    }
                }
                Array.Reverse(vetor);
                aux = "";
                foreach (int i in vetor)
                {
                    aux += i + "\n";
                }
                MessageBox.Show(aux);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList();
            lista.Remove("Otávio");

      


            

            



        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
    }
}
