﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P_Matriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                int[] vetor = new int[20];
                string aux = "";

                for (int i = 0; i < 20; i++)
                {
                    aux = Interaction.InputBox($"Digite o número {i + 1}:", "Entrada de dados");

                    if (!int.TryParse(aux, out vetor[i]))
                    {
                        MessageBox.Show("Valor inválido! Digite um número inteiro.");
                        i--;
                    }
                }
                Array.Reverse(vetor);

                aux = "Valores na ordem inversa:\n";
                foreach (int valor in vetor) 
                {
                    aux += valor + "\n";
                }

                MessageBox.Show(aux);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList listaAlunos = new ArrayList()
        {
            "Ana", "André", "Beatriz", "Camila", "João",
            "Joana", "Otávio", "Marcelo", "Pedro", "Thais"
        };
            listaAlunos.Remove("Otávio");

            string resultado = "Lista de Alunos atualizada:\n\n";

            foreach (var aluno in listaAlunos)
            {
                resultado += aluno + "\n";
            }
            MessageBox.Show(resultado);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int totalAlunos = 10;
            double[,] matrizNotas = new double[totalAlunos, 3];
            string resultadoFinal = "";

            for (int i = 0; i < totalAlunos; i++)
            {
                double soma = 0;

                for (int j = 0; j < 3; j++)
                {
                    string entrada = Interaction.InputBox($"Aluno {i + 1}\nDigite a nota {j + 1}:", "Entrada de Dados");

                    if (double.TryParse(entrada, out double nota) && nota >= 0 && nota <= 10)
                    {
                        matrizNotas[i, j] = nota;
                        soma += nota;
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido! Digite entre 0 e 10.");
                        j--; 
                    }
                }

                double media = soma / 3;


                resultadoFinal += $"Aluno {i + 1}: média: {media:F1}\n";
            }

            MessageBox.Show(resultadoFinal, "Relatório de Médias");
        
            MessageBox.Show(resultadoFinal, "Médias da Turma");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmexercicio4 tela4 = new frmexercicio4();
            this.Hide(); 

            tela4.ShowDialog(); 

            this.Show(); 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmexercicio5 tela5 = new frmexercicio5();
            this.Hide();

            tela5.ShowDialog();

            this.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
