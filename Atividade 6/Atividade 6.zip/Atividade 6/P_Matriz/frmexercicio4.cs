﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Matriz
{
    public partial class frmexercicio4 : Form
    {
        public frmexercicio4()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];

            listbx.Items.Clear();

            for (int i = 0; i < 10; i++)
            {
                string entrada = Interaction.InputBox($"Digite o nome completo da pessoa {i + 1}:", "Entrada de Nomes");

                if (string.IsNullOrWhiteSpace(entrada))
                {
                    MessageBox.Show("O nome não pode ser vazio! Tente novamente.");
                    i--;
                    continue;
                }
                nomes[i] = entrada;

                int comprimentoSemEspacos = entrada.Replace(" ", "").Length;

                tamanhos[i] = comprimentoSemEspacos;
            }
            for (int i = 0; i < 10; i++)
            {
                string linha = $"o nome:{nomes[i]} tem {tamanhos[i]} caracteres";
                listbx.Items.Add(linha);
            }
        }
    }
}