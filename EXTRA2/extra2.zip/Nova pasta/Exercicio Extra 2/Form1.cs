﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicio_Extra_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            double[,] matrizConsumo = new double[5, 4];
            double producao, escritorio, refeitorio, limpeza, logistica;
            double a;

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    string entrada = Interaction.InputBox($"{i + 1} {j + 1}");

                    if (!double.TryParse(entrada, out matrizConsumo[i, j]) || matrizConsumo[i, j] == 10) 
                    {
                        


                    }










            }

            }
        }

    }
}