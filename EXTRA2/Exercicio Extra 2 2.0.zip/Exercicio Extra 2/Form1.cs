﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicio_Extra_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            double preçolitro = 0.01;

            // Vetor com os nomes dos setores para facilitar a leitura e os loops
            string[] setores = { "Produção", "Escritório", "Refeitório", "Limpeza", "Logística" };

            // Matriz 5x4: 5 setores (linhas) e 4 semanas (colunas)
            double[,] matrizconsumo = new double[5, 4];

            // Variáveis para acumular o total geral da empresa
            double totalgerallitros = 0;
            double totalgeralreais = 0;

            // Limpa o ListBox antes de começar para não acumular resultados de cliques anteriores
            lstbx.Items.Clear();

            // O primeiro loop (i) percorre as linhas (setores)
            for (int i = 0; i < 5; i++)
            {
                // O segundo loop (j) percorre as colunas (semanas de cada setor)
                for (int j = 0; j < 4; j++)
                {
                    string valordigitado = Interaction.InputBox(
                        $"Digite o consumo em litros para o setor {setores[i]} na Semana {j + 1}:", "Entrada de Dados");

                    // Validação simples: se o usuário cancelar ou deixar em branco, assume 0
                    if (double.TryParse(valordigitado, out double consumo))
                    {
                        matrizconsumo[i, j] = consumo;
                    }
                    else
                    {
                        matrizconsumo[i, j] = 0;
                    }
                }
            }
            // Vamos percorrer a matriz novamente para calcular os totais por setor
            for (int i = 0; i < 5; i++)
            {
                double totalsetorlitros = 0;

                // Soma o consumo das 4 semanas do setor atual (linha i)
                for (int j = 0; j < 4; j++)
                {
                    totalsetorlitros += matrizconsumo[i, j];
                }

                // Calcula o valor em reais para o setor atual
                double totalsetorreais = totalsetorlitros * preçolitro;

                // Acumula os valores no total geral da empresa
                totalgerallitros += totalsetorlitros;
                totalgeralreais += totalsetorreais;

                string linhaSetor = $"{setores[i]}: {totalsetorlitros:N0} L -> {totalsetorreais:C2}";


                // Adiciona o resultado do setor no ListBox
                lstbx.Items.Add(linhaSetor);
            }

            // Adiciona a linha divisória idêntica ao exemplo do enunciado
            lstbx.Items.Add("-----------------------------");

            // Adiciona a linha final com o Total Geral acumulado
            string linhaTotalGeral = $"Total Geral: {totalgerallitros:N0} L -> {totalgeralreais:C2}";

            lstbx.Items.Add(linhaTotalGeral);
        }
    }
}
    
