﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtaltura = new System.Windows.Forms.TextBox();
            this.lblaltura = new System.Windows.Forms.Label();
            this.lblpeso = new System.Windows.Forms.Label();
            this.txtpeso = new System.Windows.Forms.TextBox();
            this.lblimc = new System.Windows.Forms.Label();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.btncalc = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtaltura
            // 
            this.txtaltura.Location = new System.Drawing.Point(292, 71);
            this.txtaltura.Name = "txtaltura";
            this.txtaltura.Size = new System.Drawing.Size(100, 26);
            this.txtaltura.TabIndex = 0;
            this.txtaltura.TextChanged += new System.EventHandler(this.txtaltura_TextChanged);
            this.txtaltura.Validated += new System.EventHandler(this.txtaltura_Validated);
            // 
            // lblaltura
            // 
            this.lblaltura.AutoSize = true;
            this.lblaltura.Location = new System.Drawing.Point(235, 74);
            this.lblaltura.Name = "lblaltura";
            this.lblaltura.Size = new System.Drawing.Size(51, 20);
            this.lblaltura.TabIndex = 1;
            this.lblaltura.Text = "Altura";
            this.lblaltura.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblpeso
            // 
            this.lblpeso.AutoSize = true;
            this.lblpeso.Location = new System.Drawing.Point(235, 119);
            this.lblpeso.Name = "lblpeso";
            this.lblpeso.Size = new System.Drawing.Size(45, 20);
            this.lblpeso.TabIndex = 2;
            this.lblpeso.Text = "Peso";
            this.lblpeso.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtpeso
            // 
            this.txtpeso.Location = new System.Drawing.Point(292, 116);
            this.txtpeso.Name = "txtpeso";
            this.txtpeso.Size = new System.Drawing.Size(100, 26);
            this.txtpeso.TabIndex = 3;
            this.txtpeso.TextChanged += new System.EventHandler(this.txtpeso_TextChanged);
            this.txtpeso.Validated += new System.EventHandler(this.txtpeso_Validated);
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Location = new System.Drawing.Point(235, 236);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(38, 20);
            this.lblimc.TabIndex = 4;
            this.lblimc.Text = "IMC";
            this.lblimc.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Location = new System.Drawing.Point(292, 233);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(100, 26);
            this.txtimc.TabIndex = 5;
            this.txtimc.TextChanged += new System.EventHandler(this.txtimc_TextChanged);
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(239, 291);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(93, 52);
            this.btncalc.TabIndex = 6;
            this.btncalc.Text = "Calcular\r\nIMC";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(360, 291);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(93, 52);
            this.btnlimpar.TabIndex = 7;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(481, 291);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(93, 52);
            this.btnsair.TabIndex = 8;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1231, 672);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.txtpeso);
            this.Controls.Add(this.lblpeso);
            this.Controls.Add(this.lblaltura);
            this.Controls.Add(this.txtaltura);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtaltura;
        private System.Windows.Forms.Label lblaltura;
        private System.Windows.Forms.Label lblpeso;
        private System.Windows.Forms.TextBox txtpeso;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.TextBox txtimc;
        private System.Windows.Forms.Button btncalc;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
    }
}

