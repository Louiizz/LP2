﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double imc, altura, peso;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));

            imc = Math.Round(imc, 1);
            txtimc.Text = imc.ToString("");

            if (imc < 18.5)
                MessageBox.Show("Magreza");
            else if (imc <= 24.9)
                MessageBox.Show("Normal");
            else if (imc <= 29.9)
                MessageBox.Show("Sobrepeso");
            else if (imc <= 39.9)
                MessageBox.Show("Obesidade");
            else
                MessageBox.Show("Obesidade Grave");











        }

        private void txtpeso_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtimc_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtpeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtpeso.Text, out peso))
            {
                MessageBox.Show("Peso Inválido");
                return;
            }
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtaltura.Clear();
            txtpeso.Clear();
            txtimc.Clear();
        }

        private void txtaltura_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtaltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtaltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
                return;





            }
        }
    }
}
