﻿namespace Atividade_5
{
    partial class frmexercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnespacoBranco = new System.Windows.Forms.Button();
            this.btnumeroR = new System.Windows.Forms.Button();
            this.btnparLetras = new System.Windows.Forms.Button();
            this.txttexto = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnespacoBranco
            // 
            this.btnespacoBranco.Location = new System.Drawing.Point(74, 436);
            this.btnespacoBranco.Name = "btnespacoBranco";
            this.btnespacoBranco.Size = new System.Drawing.Size(168, 110);
            this.btnespacoBranco.TabIndex = 0;
            this.btnespacoBranco.Text = "Espaços em Branco";
            this.btnespacoBranco.UseVisualStyleBackColor = true;
            this.btnespacoBranco.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnumeroR
            // 
            this.btnumeroR.Location = new System.Drawing.Point(320, 436);
            this.btnumeroR.Name = "btnumeroR";
            this.btnumeroR.Size = new System.Drawing.Size(168, 110);
            this.btnumeroR.TabIndex = 1;
            this.btnumeroR.Text = "Número de \"R\"";
            this.btnumeroR.UseVisualStyleBackColor = true;
            this.btnumeroR.Click += new System.EventHandler(this.btnumeroR_Click);
            // 
            // btnparLetras
            // 
            this.btnparLetras.Location = new System.Drawing.Point(561, 436);
            this.btnparLetras.Name = "btnparLetras";
            this.btnparLetras.Size = new System.Drawing.Size(168, 110);
            this.btnparLetras.TabIndex = 2;
            this.btnparLetras.Text = "Par de Letras";
            this.btnparLetras.UseVisualStyleBackColor = true;
            this.btnparLetras.Click += new System.EventHandler(this.btnparLetras_Click);
            // 
            // txttexto
            // 
            this.txttexto.Location = new System.Drawing.Point(74, 85);
            this.txttexto.Name = "txttexto";
            this.txttexto.Size = new System.Drawing.Size(655, 272);
            this.txttexto.TabIndex = 3;
            this.txttexto.Text = "";
            // 
            // frmexercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1101, 710);
            this.Controls.Add(this.txttexto);
            this.Controls.Add(this.btnparLetras);
            this.Controls.Add(this.btnumeroR);
            this.Controls.Add(this.btnespacoBranco);
            this.Name = "frmexercicio1";
            this.Text = "frmexercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnespacoBranco;
        private System.Windows.Forms.Button btnumeroR;
        private System.Windows.Forms.Button btnparLetras;
        private System.Windows.Forms.RichTextBox txttexto;
    }
}