﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício1ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<ToolStripMenuItem>().Count() > 0)
            {
                Application.OpenForms["frmexercicio1"].BringToFront();
            }
            else
            {
                frmexercicio1 frmexercicio = new frmexercicio1();
                frmexercicio.MdiParent = this;
                frmexercicio.WindowState = FormWindowState.Maximized;
                frmexercicio.Show();
            }


        }
    }
}
