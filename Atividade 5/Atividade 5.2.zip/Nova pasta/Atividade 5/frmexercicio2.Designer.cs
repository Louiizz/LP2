﻿namespace Atividade_5
{
    partial class frmexercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmaiorquezero = new System.Windows.Forms.Label();
            this.txtnumeromaiorquezero = new System.Windows.Forms.TextBox();
            this.btnh = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblmaiorquezero
            // 
            this.lblmaiorquezero.AutoSize = true;
            this.lblmaiorquezero.Location = new System.Drawing.Point(119, 73);
            this.lblmaiorquezero.Name = "lblmaiorquezero";
            this.lblmaiorquezero.Size = new System.Drawing.Size(119, 13);
            this.lblmaiorquezero.TabIndex = 0;
            this.lblmaiorquezero.Text = "Número maior que zero:";
            // 
            // txtnumeromaiorquezero
            // 
            this.txtnumeromaiorquezero.Location = new System.Drawing.Point(245, 73);
            this.txtnumeromaiorquezero.Name = "txtnumeromaiorquezero";
            this.txtnumeromaiorquezero.Size = new System.Drawing.Size(153, 20);
            this.txtnumeromaiorquezero.TabIndex = 1;
            // 
            // btnh
            // 
            this.btnh.Location = new System.Drawing.Point(122, 99);
            this.btnh.Name = "btnh";
            this.btnh.Size = new System.Drawing.Size(75, 40);
            this.btnh.TabIndex = 2;
            this.btnh.Text = "H";
            this.btnh.UseVisualStyleBackColor = true;
            this.btnh.Click += new System.EventHandler(this.btnh_Click);
            // 
            // frmexercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnh);
            this.Controls.Add(this.txtnumeromaiorquezero);
            this.Controls.Add(this.lblmaiorquezero);
            this.Name = "frmexercicio2";
            this.Text = "frmexercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmaiorquezero;
        private System.Windows.Forms.TextBox txtnumeromaiorquezero;
        private System.Windows.Forms.Button btnh;
    }
}