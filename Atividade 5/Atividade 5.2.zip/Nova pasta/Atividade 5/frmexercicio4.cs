﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class frmexercicio4 : Form
    {
        public frmexercicio4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnsalariobruto_Click(object sender, EventArgs e)
        {
            int producao, x = 0, y = 0, z = 0;
            double salario, gratificacao, salariobruto;
            string nome;

            nome = txtnome.Text;
            producao = Convert.ToInt32(txtproducao.Text);
            salario = Convert.ToDouble(txtsalario.Text);
            gratificacao = Convert.ToDouble(txtgratificacao.Text);

            if (producao >= 100)
                x = 1;

            if (producao >= 120)
                y = 1;

            else
                z = 1;

            salariobruto = salario + (salario * ((0.05 * x) + (0.10 * y) + (1 * z)));

            if (salariobruto > 7000)
            {
                if (producao >= 150 && gratificacao > 0)
                {
                    MessageBox.Show("Funcionário: " + nome + "\nSalário Bruto: R$ " + salariobruto.ToString("F2"));
                }
                else
                {
                    salariobruto = 7000;
                    MessageBox.Show("Funcionário: " + nome + "\nSalário Bruto: R$ " + salariobruto.ToString("F2"));
                }
            }
            else
            {
                MessageBox.Show("Funcionário: " + nome + "\nSalário Bruto: R$ " + salariobruto.ToString("F2"));
            }

        

            












        }   
    }
}
