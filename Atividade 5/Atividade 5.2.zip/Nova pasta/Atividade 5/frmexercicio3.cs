﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class frmexercicio3 : Form
    {
        public frmexercicio3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string frase, textoLimpo = "", invertido = "";
            frase = txtfrase.Text.ToUpper();

            for (int i = 0; i < frase.Length; i++)
            {
                if (frase[i] != ' ')
                {
                    textoLimpo += frase[i];
                }
            }
            for (int i = textoLimpo.Length - 1; i >= 0; i--)
            {
                invertido += textoLimpo[i];
            }
            if (textoLimpo == invertido)
            {
                MessageBox.Show("É um palídrono");
            }
            else
            {
                MessageBox.Show("Não é um palídromo");
            }

        }
    }
}
