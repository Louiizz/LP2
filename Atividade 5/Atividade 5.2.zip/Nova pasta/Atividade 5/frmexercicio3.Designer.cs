﻿namespace Atividade_5
{
    partial class frmexercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtfrase = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnpalindromo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtfrase
            // 
            this.txtfrase.AutoSize = true;
            this.txtfrase.Location = new System.Drawing.Point(21, 46);
            this.txtfrase.Name = "txtfrase";
            this.txtfrase.Size = new System.Drawing.Size(39, 13);
            this.txtfrase.TabIndex = 0;
            this.txtfrase.Text = "Frase: ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(57, 43);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(268, 20);
            this.textBox1.TabIndex = 1;
            // 
            // btnpalindromo
            // 
            this.btnpalindromo.Location = new System.Drawing.Point(24, 69);
            this.btnpalindromo.Name = "btnpalindromo";
            this.btnpalindromo.Size = new System.Drawing.Size(75, 23);
            this.btnpalindromo.TabIndex = 2;
            this.btnpalindromo.Text = "Palíndromo";
            this.btnpalindromo.UseVisualStyleBackColor = true;
            this.btnpalindromo.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmexercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnpalindromo);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtfrase);
            this.Name = "frmexercicio3";
            this.Text = "frmexercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtfrase;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnpalindromo;
    }
}