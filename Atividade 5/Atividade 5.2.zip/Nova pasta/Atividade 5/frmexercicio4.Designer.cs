﻿namespace Atividade_5
{
    partial class frmexercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnome = new System.Windows.Forms.Label();
            this.lblmatricula = new System.Windows.Forms.Label();
            this.lblproducao = new System.Windows.Forms.Label();
            this.lblsalario = new System.Windows.Forms.Label();
            this.lblgratificacao = new System.Windows.Forms.Label();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.txtproducao = new System.Windows.Forms.TextBox();
            this.txtsalario = new System.Windows.Forms.TextBox();
            this.txtgratificacao = new System.Windows.Forms.TextBox();
            this.btnsalariobruto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(30, 36);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(38, 13);
            this.lblnome.TabIndex = 0;
            this.lblnome.Text = "Nome:";
            this.lblnome.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblmatricula
            // 
            this.lblmatricula.AutoSize = true;
            this.lblmatricula.Location = new System.Drawing.Point(30, 66);
            this.lblmatricula.Name = "lblmatricula";
            this.lblmatricula.Size = new System.Drawing.Size(55, 13);
            this.lblmatricula.TabIndex = 1;
            this.lblmatricula.Text = "Matrícula:";
            // 
            // lblproducao
            // 
            this.lblproducao.AutoSize = true;
            this.lblproducao.Location = new System.Drawing.Point(30, 98);
            this.lblproducao.Name = "lblproducao";
            this.lblproducao.Size = new System.Drawing.Size(59, 13);
            this.lblproducao.TabIndex = 2;
            this.lblproducao.Text = "Produção: ";
            // 
            // lblsalario
            // 
            this.lblsalario.AutoSize = true;
            this.lblsalario.Location = new System.Drawing.Point(30, 129);
            this.lblsalario.Name = "lblsalario";
            this.lblsalario.Size = new System.Drawing.Size(42, 13);
            this.lblsalario.TabIndex = 3;
            this.lblsalario.Text = "Salário:";
            // 
            // lblgratificacao
            // 
            this.lblgratificacao.AutoSize = true;
            this.lblgratificacao.Location = new System.Drawing.Point(30, 161);
            this.lblgratificacao.Name = "lblgratificacao";
            this.lblgratificacao.Size = new System.Drawing.Size(67, 13);
            this.lblgratificacao.TabIndex = 4;
            this.lblgratificacao.Text = "Gratificação:";
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(74, 36);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(114, 20);
            this.txtnome.TabIndex = 5;
            // 
            // txtmatricula
            // 
            this.txtmatricula.Location = new System.Drawing.Point(91, 63);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(114, 20);
            this.txtmatricula.TabIndex = 6;
            // 
            // txtproducao
            // 
            this.txtproducao.Location = new System.Drawing.Point(95, 95);
            this.txtproducao.Name = "txtproducao";
            this.txtproducao.Size = new System.Drawing.Size(114, 20);
            this.txtproducao.TabIndex = 7;
            // 
            // txtsalario
            // 
            this.txtsalario.Location = new System.Drawing.Point(78, 126);
            this.txtsalario.Name = "txtsalario";
            this.txtsalario.Size = new System.Drawing.Size(114, 20);
            this.txtsalario.TabIndex = 8;
            // 
            // txtgratificacao
            // 
            this.txtgratificacao.Location = new System.Drawing.Point(103, 158);
            this.txtgratificacao.Name = "txtgratificacao";
            this.txtgratificacao.Size = new System.Drawing.Size(114, 20);
            this.txtgratificacao.TabIndex = 9;
            // 
            // btnsalariobruto
            // 
            this.btnsalariobruto.Location = new System.Drawing.Point(33, 193);
            this.btnsalariobruto.Name = "btnsalariobruto";
            this.btnsalariobruto.Size = new System.Drawing.Size(75, 24);
            this.btnsalariobruto.TabIndex = 10;
            this.btnsalariobruto.Text = "Salário Bruto";
            this.btnsalariobruto.UseVisualStyleBackColor = true;
            this.btnsalariobruto.Click += new System.EventHandler(this.btnsalariobruto_Click);
            // 
            // frmexercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsalariobruto);
            this.Controls.Add(this.txtgratificacao);
            this.Controls.Add(this.txtsalario);
            this.Controls.Add(this.txtproducao);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.lblgratificacao);
            this.Controls.Add(this.lblsalario);
            this.Controls.Add(this.lblproducao);
            this.Controls.Add(this.lblmatricula);
            this.Controls.Add(this.lblnome);
            this.Name = "frmexercicio4";
            this.Text = "frmexercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblmatricula;
        private System.Windows.Forms.Label lblproducao;
        private System.Windows.Forms.Label lblsalario;
        private System.Windows.Forms.Label lblgratificacao;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.TextBox txtproducao;
        private System.Windows.Forms.TextBox txtsalario;
        private System.Windows.Forms.TextBox txtgratificacao;
        private System.Windows.Forms.Button btnsalariobruto;
    }
}