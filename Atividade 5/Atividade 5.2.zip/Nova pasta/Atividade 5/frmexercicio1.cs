﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class frmexercicio1 : Form
    {
        public frmexercicio1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < txttexto.Text.Length; i++)
            {
                if (char.IsWhiteSpace(txttexto.Text[i]))
                {
                    posicao = i + 1;
                    break;

                }

            }
            MessageBox.Show($"O texto tem {posicao} espaços brancos");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTexto_Validated(object sender, EventArgs e)
        {

        }

        private void btnumeroR_Click(object sender, EventArgs e)
        {
            int i = 0;
            int contador = 0;
          

            while (i < txttexto.Text.Length)
            {
                if(txttexto.Text[i] == 'R' || txttexto.Text[i] == 'r')
                    contador++;
            }
            MessageBox.Show($"Quantidade de letras R ou r: {contador}");
        }

        private void btnparLetras_Click(object sender, EventArgs e)
        {
            string texto = txttexto.Text.ToLower();
            int pares = 0;

            for (int i = 0; i < txttexto.Text.Length - 1; i++)
            {
                if (texto[i] == texto[i + 1])
                {
                    pares++;
                }

            }
            MessageBox.Show($"A frase tem {pares} pares de letras");
        }
    }
}
    