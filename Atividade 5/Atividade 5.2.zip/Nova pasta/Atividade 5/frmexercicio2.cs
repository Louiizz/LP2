﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class frmexercicio2 : Form
    {
        int numero;
            int H;
        public frmexercicio2()
        {
            InitializeComponent();
        }

        private void btnh_Click(object sender, EventArgs e)
        {
            int numero;
            double H = 0;
            numero = Convert.ToInt32(txtnumeromaiorquezero.Text);

            if (numero <= 0)
            {
                txtnumeromaiorquezero.Focus();
            }
            else
            {
                for (int i = 1; i <= numero; i++)
                {
                    H = H + (1.0 / i); 
                }
                MessageBox.Show("Valor de H: " + H.ToString("F2")); 

            }


        }
    }
}
