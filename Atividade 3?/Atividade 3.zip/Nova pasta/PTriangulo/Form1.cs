﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {

        double ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtladoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtladoB.Text, out ladoB))
            {
                MessageBox.Show("Valor B Inválido");
                txtladoB.Focus();
            }
        }

        private void txtladoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtladoC.Text, out ladoC))
            {
                MessageBox.Show("Valor C Inválido");
                txtladoC.Focus();

            }

        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            if ((ladoA < (ladoB + ladoC)) && (ladoA > Math.Abs(ladoB - ladoC) &&
               (ladoB < (ladoA + ladoC)) && (ladoB > Math.Abs(ladoA - ladoC) &&
               (ladoC < (ladoB + ladoA)) && (ladoC > Math.Abs(ladoA - ladoB)))))
            {
                if ((ladoA == ladoB) && (ladoB == ladoC) && (ladoA == ladoC))
                    MessageBox.Show("Triângulo Equilátero");
            }
            { 
                if ((ladoA == ladoB) || (ladoB == ladoC) || (ladoA == ladoC))
                    MessageBox.Show("Triangulo Isósceles");
                else
                    MessageBox.Show("Triangulo Escaleno");
            }

            }
        

        private void btnlimpar_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtladoA_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtladoC_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtladoB_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtladoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtladoA.Text, out ladoA))
            {
                MessageBox.Show("Valor A Inválido");
                txtladoA.Focus();
                
            }
         
            


        }
    }
}
